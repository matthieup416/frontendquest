import React from "react"
import { View, Text, Button } from "react-native"
import Icon from "react-native-vector-icons/FontAwesome5"
import { connect } from "react-redux"

function ExplorerScreen(props) {
  return (
    <View style={{ flex: 1, justifyContent: "flex-end" }}>
      <Text>CARTE EXPLORER</Text>
    </View>
  )
}

export default ExplorerScreen
